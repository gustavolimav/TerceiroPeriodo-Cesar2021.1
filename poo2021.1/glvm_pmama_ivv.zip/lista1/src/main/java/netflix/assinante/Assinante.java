package assinante.Assinante;
import plano.Plano;
import titulo.Titulo;

public class Assinante {
    public String nome;
    public String plano;
    public Plano plano;
    ArrayList<Titulo> historico=new ArrayList<Titulo>();
}