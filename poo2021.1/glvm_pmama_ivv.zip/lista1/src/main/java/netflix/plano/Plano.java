public class Plano {
    public double valor;
    public String nome;
}