package netflix.titulo;
import java.util.ArrayList;
import java.util.List;

import netflix.genero.Genero;

public class Titulo {
    public String titulo;
    public Genero generoPrincipal;
    public String sinopse;
    public List<Genero> generos=new ArrayList<Genero>();
    
    public void getGeneros() {
        
    }

}