package netflix.genero;

public class Genero {
    public String name;
    public boolean maioridade;

    public String getName() {
        return this.name;
    }
    
    public boolean getMaioridade() {
        return this.maioridade;
    }
}