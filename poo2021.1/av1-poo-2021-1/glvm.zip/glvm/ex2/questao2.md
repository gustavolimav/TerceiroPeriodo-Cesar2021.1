# Questão 2

## Identifique cada uma das coleções usadas na questão anterior e a razao para adotá-la em detrimento das outras opções.

### Livro.autores: 
"java.util.ArrayList", foi utilizada essa coleção para utilizar um ArrayList de todos os autores existentes, toda via não será possivel adicionar vário de uma vez.

### Livro.tags: 
"java.util.Set" "java.util.HashSet" "java.util.LinkedHashSet", foi utilizada essa coleção para implementar uma lista de Array com todas as tags sem repetição e tem ordem sorteada.


### Autor.obras: 
"java.util.Set" "java.util.HashSet" "java.util.LinkedHashSet", foi utilizada essa coleção para implementar uma lista de Array com todas as obras sem repetição e tem ordem sorteada.

### Catalogo.livros:
"java.util.ArrayList", foi utilizada essa coleção para implementar uma lista de Array com todos os livros.

