# Questão 3

## Estudamos mais a fundo, até agora, dois dos quatro modificadores de acesso do Java: o public e o private. Explique, com suas palavras, a diferença e as aplicações de ambos.

## Resposta:

A principal diferença entre as duas é que em modificadores private a única classe que pode ter acesso ao atributo é a própria classe que está o definindo, já a public todos tem acesso.

Em java por boa prática utiliza-se encapsulamento para proteger os dados do programa e para proteger eles os modificadores das variáveis são definidos como privados e é utilizado modificadores publicos em geters e seters para utilizar as informações definidas como private.