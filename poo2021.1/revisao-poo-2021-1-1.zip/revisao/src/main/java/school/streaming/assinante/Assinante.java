package school.streaming.assinante;

public class Assinante {
    
}
