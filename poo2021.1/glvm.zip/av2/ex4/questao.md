# Questão 4
Quando lidamos com hierarquias de classes no Java deparamos com os conceitos de sobrescrita e sobrecarga de métodos. Explique, com suas palavras, ambos os conceitos e as principais diferenças entre eles.
## Resposta:

Sobrescrita: com a sobrescrita é possivel especializar o metodo herdado da sulperclasse, alterando o comportamento na subclasse por uma mais específico. Basicamente uma classe filha pode redefinir métodos herdados de suas descendentes.

Sobrecarga: permite, na mesma classe, mais de um método com o mesmo nome, mas pra funcionar é preciso ter argumentos diferentes para que seja feita a separação dos mesmos.

