# Questão 3
Temos no Java os conceitos de Classes Abstratas e Interfaces. Explique, com suas palavras, ambos os conceitos, suas principais diferenças e aplicações.
## Resposta:
