# Questão 4
Quando lidamos com hierarquias de classes no Java deparamos com os conceitos de sobrescrita e sobrecarga de métodos. Explique, com suas palavras, ambos os conceitos e as principais diferenças entre eles.
## Resposta:
