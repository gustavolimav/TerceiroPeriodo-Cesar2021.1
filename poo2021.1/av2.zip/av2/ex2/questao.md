# Questao 2

O arquivo dump.bin foi criado a partir da classe school.cesar.av2.ex2.Dump. Entretanto os valores das leituras foram substituídos por zero após a execução.
Completem a classe school.cesar.av2.ex2.Reload de tal forma que ela seja capaz de ler o arquivo dump.bin e apresentar os valores do campo leitura que foram salvos na execução da classe Dump.