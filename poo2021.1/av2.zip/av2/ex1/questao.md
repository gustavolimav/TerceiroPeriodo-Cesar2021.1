# Questao 1

O arquivo ids.txt contem vários números. Escreva uma aplicação em Java, usando os conceitos de I/O e de coleções vistos em sala, capaz de indicar a quantidade de números distintos presentes no arquivo ids.txt